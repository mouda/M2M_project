close all
clear all

m(1, :) = 1:10;
% m(2, :) = 2:11;

q = mean(m, 1);